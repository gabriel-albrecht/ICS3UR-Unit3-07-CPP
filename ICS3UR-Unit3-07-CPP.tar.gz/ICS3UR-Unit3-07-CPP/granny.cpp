// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Dec 2020
// This is a program that predicts if you'll be able to marry

#include <iostream>
#include <string>

int main() {
    int age;
    std::string ageAsString;

    // input
    std::cout << "Will your girlfriend's grandma allow you to marry her?" <<
    std::endl;
    std::cout << "Enter your age: ";
    std::cin >> ageAsString;
    std::cout << "" << std::endl;

    try {
        age = std::stoi(ageAsString);

        if (age <= 40 && age >= 25) {
            std::cout << "Looks like she will allow you two to marry!";
        } else {
            std::cout << "No chance :(" << std::endl;
            std::cout << "You have to be between 25-40 years old" << std::endl;
        }
    } catch (std::invalid_argument) {
        std::cout << "" << std::endl;
        std::cout << "ERROR: ENTERED INVALID CHARACTER(S)" << std::endl;
    }
}
